package com.manalo.rabbitmq;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		
		AbstractApplicationContext context = new ClassPathXmlApplicationContext(
				"spring-config.xml");

		HelloWorld hello = context.getBean(HelloWorld.class);
		hello.printHello();
		
		context.close();
		
	}

}
